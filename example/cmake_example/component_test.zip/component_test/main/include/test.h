

#ifndef TEST_H_
#define TEST_H_
#if defined(__cplusplus)
extern "C" {
#endif

#include <stdio.h>


uint32_t get_test_data(void);


void set_test_data(uint32_t data);


#if defined(__cplusplus)
}
#endif

#endif /* TEST_H_ */