# Add Components Example

Explain how to add components in project.

esp-idf version : c3324a82a (HEAD -> release/v4.1, origin/release/v4.1)